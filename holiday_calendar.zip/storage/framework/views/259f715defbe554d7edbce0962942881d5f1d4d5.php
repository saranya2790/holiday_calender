<!-- resources/views/calendar.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Holiday Calendar</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table th, .table td {
            text-align: center;
            vertical-align: middle;
        }
        .table td {
            width: 14%;
            height: auto;
        }
        .holiday {
            background-color: #ffcccc;
        }
        .other-month {
            background-color: #f9f9f9;
        }
        .navigation {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">Holiday Calendar</h1>
        <div class="navigation mb-4">
            <form method="POST" action="/calendar" class="form-inline">
                <?php echo csrf_field(); ?>
                <div class="form-group mr-2">
                    <label for="month" class="mr-2">Month:</label>
                    <select name="month" id="month" class="form-control">
                        <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($m == $month ? 'selected' : ''); ?>><?php echo e(date('F', mktime(0, 0, 0, $m, 1))); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group mr-2">
                    <label for="year" class="mr-2">Year:</label>
                    <input type="number" name="year" id="year" class="form-control" value="<?php echo e($year); ?>">
                </div>
                <div class="btn-group" role="group">
                    <button type="submit" name="action" value="prev" class="btn btn-secondary">Prev</button>
                    <button type="submit" name="action" value="today" class="btn btn-secondary">Today</button>
                    <button type="submit" name="action" value="next" class="btn btn-secondary">Next</button>
                </div>
                <button type="submit" class="btn btn-primary ml-2">Go</button>
            </form>
        </div>

        <?php
            $startOfMonth = \Carbon\Carbon::create($year, $month, 1);
            $endOfMonth = $startOfMonth->copy()->endOfMonth();
            $startOfWeek = $startOfMonth->copy()->startOfWeek();
            $endOfWeek = $endOfMonth->copy()->endOfWeek();
            $currentDate = $startOfWeek->copy();
        ?>

        <table class="table table-bordered">
            <thead class="thead-light">
                <tr colspan="6" class="thead-light">
                    <center><h3><?php echo e(date('F', mktime(0, 0, 0, $month, 1))); ?> - <?php echo e($year); ?></h3><center>
                </tr>
                <tr>
                    <?php $__currentLoopData = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($day); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                
                <?php while($currentDate <= $endOfWeek): ?>
                    <tr>
                        <?php $__currentLoopData = range(0, 6); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="<?php echo e($currentDate->month != $month ? 'other-month' : ''); ?> <?php echo e($holidays->where('date', $currentDate->toDateString())->isNotEmpty() ? 'holiday' : ''); ?>">
                                <?php echo e($currentDate->day); ?>

                                <?php if($holidays->where('date', $currentDate->toDateString())->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $holidays->where('date', $currentDate->toDateString()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div><?php echo e($holiday->name); ?> (<?php echo e($holiday->type); ?>)</div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <?php $currentDate->addDay(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH E:\xampp_8\htdocs\holiday_calendar\resources\views/calendar.blade.php ENDPATH**/ ?>